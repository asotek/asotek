# Docker-CODE
Dockerfile and scripts to generate CODE Docker image

Usage and possible settings are documented on the [CODE home page](https://collaboraoffice.com/code/).
